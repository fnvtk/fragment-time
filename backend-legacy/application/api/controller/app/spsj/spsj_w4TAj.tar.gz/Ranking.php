<?php


namespace app\api\controller\app\spsj;


use app\common\controller\Api;
use EasyWeChat\Factory;
use think\Db;

class Ranking extends Api
{
    protected $noNeedLogin = ['*'];
    protected $noNeedRight = ['*'];

    public function _initialize()
    {
        parent::_initialize();
        $appid = input('appid');
        $this->loginType = input('loginType', 'wechat');
        if (empty($appid)) {
            $this->error('重要参数缺失');
        }

    }


    public function projectList()
    {
        if ($this->request->isPost()) {
            $list = Db::table('WechatApp_project')
                ->where(array('status' => 1))
                ->order('id DESC')
                ->select();

            $this->success('获取成功', $list);
        } else {
            $this->error('非法访问');
        }
    }


    public function rankingList()
    {
        if ($this->request->isPost()) {
            $appid = 1;
            $projectId = $this->request->post('projectId');
            $userId = $this->request->post('uid', 1);
            $companyId = input('companyId',0);



            $where = [];
            $where['type'] = 1;
            if (!empty($projectId)) {
                $where['projectId'] = $projectId;
            }

            $where['companyId'] = $companyId;

            if (!empty($companyId)){
                $setting = Db::table('WechatApp_setting')
                    ->where(['appId'=>$appid,'companyId' => $companyId])
                    ->find();
            }else{
                $setting = Db::table('WechatApp')
                    ->where('id', $appid)
                    ->find();
            }
            //计算n天收益
            $day = 3650;
            $today = strtotime(date('Y-m-d H:i:s'));

            //列出有参与活动的用户
            $user = Db::table('WechatApp_bill')
                ->field('id,uid')
                ->where($where)
                ->whereBetween('createTime', [date('Y-m-d H:i:s', $today - 86400 * $day), date('Y-m-d H:i:s', $today)])
                ->group('uid')
                ->select();
            $myRanking = [];
            foreach ($user as $key => &$val) {
                if ($setting['showTaskMoney']){
                    //计算出总收益
                    $val['sumCount'] = Db::table('WechatApp_bill')
                        ->where($where)
                        ->whereBetween('createTime', [date('Y-m-d H:i:s', $today - 86400 * $day), date('Y-m-d H:i:s', $today)])
                        ->where('uid', $val['uid'])
                        ->sum('money');


                    $val['money'] = Db::table('WechatApp_bill')
                        ->where(array('uid' => $val['uid'], 'type' => 1))
                        ->whereBetween('createTime', [date('Y-m-d H:i:s', $today - 86400 * $day), date('Y-m-d H:i:s', $today)])
                        ->sum('money');
                    if ($val['money'] >= 100) {
                        $val['profit'] = intval($val['money'] / 100) * 100 * 5.5;
                    } else {
                        $val['profit'] = intval($val['money'] / 10) * 10 * 5.5;
                    }
                }else{
                    //计算出总任务数
                    $val['sumCount'] = Db::table('WechatApp_taskReceive')
                        ->where(['status' =>2])
                        ->whereBetween('createTime', [date('Y-m-d H:i:s', $today - 86400 * $day), date('Y-m-d H:i:s', $today)])
                        ->where('uid', $val['uid'])
                        ->count();
                }


                $fans = Db::table('WechatApp_fans')
                    ->field('id,openid,nickName,mobile,avatarUrl')
                    ->where('id', $val['uid'])
                    ->find();

                if (!empty($fans)) {
                    $val['phone'] = $this->substrCut($fans['mobile']);
                    $val['nickName'] = $this->substrCut($fans['nickName']);
                    $val['avatarUrl'] = $fans['avatarUrl'];
                    $val['openid'] = $fans['openid'];
                } else {
                    $val['phone'] = '-';
                    $val['nickName'] = '-';
                    $val['avatarUrl'] = '-';
                    $val['openid'] = '-';
                }


            }
            unset($val);

            //根据收益排序
            $keys = array_column($user, 'sumCount');
            array_multisort($keys, SORT_DESC, $user);

            foreach ($user as $k => &$v) {
                $v['ranking'] = $k + 1;
                //列出自己的排名
                if ($v['uid'] == $userId) {
                    $myRanking = $v;
                }
            }
            unset($v);
            $user = array_slice($user, 0, 10);
            $data = [
                'list' => $user,
                'myRanking' => $myRanking,
            ];
            $this->success('获取成功', $data);
        } else {
            $this->error('非法访问');
        }
    }


    /**
     * *号
     * @param $userName
     * @return string
     */
    public function substrCut($userName)

    {
        $strlen = mb_strlen($userName, 'utf-8');
        $firstStr = mb_substr($userName, 0, 3, 'utf-8');
        $lastStr = mb_substr($userName, -3, 3, 'utf-8');
        $resultName = $firstStr . '****' . $lastStr;
        return $resultName;

    }


}